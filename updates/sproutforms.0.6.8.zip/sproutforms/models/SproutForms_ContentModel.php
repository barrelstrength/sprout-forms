<?php
namespace Craft;

class SproutForms_ContentModel extends \CFormModel
{
    
    /**
     * Define validation rules
     * 
     * @return void
     */
    public function rules()
    {
        return $this->rules;
    }
}